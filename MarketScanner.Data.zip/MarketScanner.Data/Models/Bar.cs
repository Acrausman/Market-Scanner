﻿public class Bar
{
    public double Close { get; set; }
    public double Volume { get; set; }
    public DateTime Timestamp { get; set; }
}
